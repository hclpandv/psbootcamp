﻿# If you want to change the output folder, replace below line with a complete path,
# for example  $OutputFolder = "D:\"
$OutputFolder = $Scriptdir

# Year, used in the documents and in the registry keys
$Year = (Get-date -format "yyyy")

# Using the $year folder of the DSL as default repository, change when needed
$Repository = "\\Solon.prd\Files\P\Global\Technical\Appsource\UrbanCodeDeploy\" + $Year

# This is the text in the main.ps1 for a component
$COcomments = @'
   <# ################################################################################
    # Below are 5 different installer options. Just remove the ones you don't need for your project.

    # Installing program using Windows Installer
    Write-Log -Message "Installing $Name..."
    $AppLogFile = $LogDir + "\" + $Name.Replace(" ", "") + "_MSI_Install.log" 
    msiexec.exe /i "$($ScriptDir)\<MSI Name>.msi" [TRANSFORMS="<MST Name.mst>"] ALLUSERS=2 /passive /norestart /log "$($AppLogFile)" | Out-Null
    Check-ExitCode -Code $LastExitCode

    # Installing program using Executable and an argument list
    $Exe = "`"$ScriptDir\<Executable Name>.exe`""
    $Parameters = @()
    $Parameters += "<first parameter> "
    $Parameters += "<second parameter> "
    Write-Log -Message "Installing $Name..."
           ## IF YOU NEED TO RUN THE INSTALLATION UNDER DIFFERENT CREDENTIALS, UNCOMMENT THE FOLLOWING LINES:
           ## $Process = New-Object System.Diagnostics.Process
           ## If (!($env:husername -match '\\')) { $Process.StartInfo.UserName = "Solon\" + $Env:husername }
           ## Else { $Process.StartInfo.UserName = $Env:husername }
           ## $Process.StartInfo.Password = $Env:hpassword | ConvertTo-SecureString -AsPlainText -Force
           ## ## Write-Log -Message "Installing as user $($Process.StartInfo.Username)" -Type "Information"
    $Process = [Diagnostics.Process]::Start("$Exe", "$Parameters")
    $Process.WaitForExit()
    Check-ExitCode -Code $Process.ExitCode

    # Installing program using executable and a single string with parameters
    Write-Log -Message "Installing $Name..."
           ## IF YOU NEED TO RUN THE INSTALLATION UNDER DIFFERENT CREDENTIALS, UNCOMMENT THE FOLLOWING LINES:
           ## $Process = New-Object System.Diagnostics.Process
           ## If (!($env:husername -match '\\')) { $Process.StartInfo.UserName = "Solon\" + $Env:husername }
           ## Else { $Process.StartInfo.UserName = $Env:husername }
           ## $Process.StartInfo.Password = $Env:hpassword | ConvertTo-SecureString -AsPlainText -Force
           ## ## Write-Log -Message "Installing as user $($Process.StartInfo.Username)" -Type "Information"
    $Process = [Diagnostics.Process]::Start("Notepad.exe","")
    $Process.WaitForExit()
    Check-ExitCode -Code $Process.ExitCode

    # Installing program patch using Windows Installer
    Write-Log -Message "Applying update for $ComponentName..."
    $AppLogFile = $LogDir + "\" + $Name.Replace(" ", "") + "_MSP_Install.log"
    msiexec.exe /p "$($ScriptDir)\<Patch Name>.msp" ALLUSERS=2 /passive /norestart /log "$($AppLogFile)" | Out-Null
    Check-ExitCode -Code $LastExitCode
    
    # Installing program using a VB script
    Write-Log -Message ("Installing " + $Name + " ...")
    Start-Process -FilePath "Cscript.exe" -ArgumentList ($ScriptDir + "\Appl\InstallApp.vbs") -wait
    $ReturnCode = Check-ExitCode -Code $LastExitCode
    
    ################################################################################ #>
'@ 

# This is the text in the main.ps1 for a system
$SYcomments = @'
    #
    #
    # Place your custom lines here
    # 
    #
'@ 

# This is the text in the main.ps1 for a uCD Controlled Manual Install
$UCMIcomments = @'
    Write-Log -Message "UDeploy Controlled Manual Installation,"
    Write-Log -Message "Copying installation source to d:\Install."
    ROBOCOPY "$ScriptDir\Appl" /S /E D:\Install >> C:\Logfiles\----LOGFILE----
'@ 