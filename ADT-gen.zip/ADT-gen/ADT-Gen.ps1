# ------------------------------------------------------------------------------
#   Name      ADT-Gen.ps1
#   Author    S.R. Kok
#   Purpose   This script is used to create standard folderstructures for
#             application deployment with uDeploy.
#   Version   16-11-2016
# ------------------------------------------------------------------------------ 
# -------- Script constants
$ScriptDir  = Split-Path $script:MyInvocation.MyCommand.Path
$Init       = $Scriptdir + "\Init.ps1"
$Functions  = $Scriptdir + "\Functions.ps1"
$Form       = $ScriptDir + "\Form.ps1"
$ADTVersion = "1.8"



# -------- Includes / dot sources
. $Init
. $Functions
. $Form



# -------- Show the form
[System.Windows.Forms.Application]::Run($frmMain)

