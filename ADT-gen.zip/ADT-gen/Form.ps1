﻿# ------------------------------------------------------------------------------
#   Form.ps1  is the form displayed by the ADT-Gen.ps1 script.
# ------------------------------------------------------------------------------ 
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Windows.Forms 

$fntMain = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold)



# ------------------------------------------------------------------------------
#   Form - Background
# ------------------------------------------------------------------------------
$global:frmMain = New-Object System.Windows.Forms.Form 
$frmMain.Text = "Automated Deployment Template Generator"
$frmMain.Size = New-Object System.Drawing.Size(750,470) 
$frmMain.StartPosition = "CenterScreen"
$frmMain.FormBorderStyle="None"
$frmMain.ControlBox = $False
$frmMain.KeyPreview = $True   # This makes sure the keystrokes are sent to the form itself first, instead of directly to the control which has the focus.
$frmMain.Icon = ($Scriptdir + "\ADT-Gen.ico")
MakeControlmovable($frmMain)



# ------------------------------------------------------------------------------
#   Lines drawn on background and sides
# ------------------------------------------------------------------------------
$pnlTop = New-Object System.Windows.Forms.Panel
$pnlTop.Location = New-Object System.Drawing.Point(0,0)
$pnlTop.BackColor = "DimGray"
$pnlTop.Size = New-Object System.Drawing.Size(750,1)
$frmMain.Controls.Add($pnlTop)


$pnlBottom = New-Object System.Windows.Forms.Panel
$pnlBottom.Location = New-Object System.Drawing.Point(0,469)
$pnlBottom.BackColor = "DimGray"
$pnlBottom.Size = New-Object System.Drawing.Size(750,1)
$frmMain.Controls.Add($pnlBottom)


$pnlLeft = New-Object System.Windows.Forms.Panel
$pnlLeft.Location = New-Object System.Drawing.Point(0,0)
$pnlLeft.BackColor = "DimGray"
$pnlLeft.Size = New-Object System.Drawing.Size(1,470)
$frmMain.Controls.Add($pnlLeft)


$pnlRight = New-Object System.Windows.Forms.Panel
$pnlRight.Location = New-Object System.Drawing.Point(749,0)
$pnlRight.BackColor = "DimGray"
$pnlRight.Size = New-Object System.Drawing.Size(1,469)
$frmMain.Controls.Add($pnlRight)


$pnlSeparator1 = New-Object System.Windows.Forms.Panel
$pnlSeparator1.Location = New-Object System.Drawing.Point(10, 201)
$pnlSeparator1.BackColor = "DimGray"
$pnlSeparator1.Size = New-Object System.Drawing.Size(730, 1)
$frmMain.Controls.Add($pnlSeparator1)
MakeControlmovable($pnlSeparator1)


$pnlSeparator2 = New-Object System.Windows.Forms.Panel
$pnlSeparator2.Location = New-Object System.Drawing.Point(10, 234)
$pnlSeparator2.BackColor = "DimGray"
$pnlSeparator2.Size = New-Object System.Drawing.Size(730, 1)
$frmMain.Controls.Add($pnlSeparator2)
MakeControlmovable($pnlSeparator2)



# ------------------------------------------------------------------------------
#   Buttons upper right plus blue top panel
# ------------------------------------------------------------------------------
$lblExit = New-Object System.Windows.Forms.Label
$lblExit.Font = New-Object System.Drawing.Font("Segoe UI", 15.75, [System.Drawing.FontStyle]::Bold)
$lblExit.ForeColor = "White"
$lblExit.BackColor = "Steelblue"
$lblExit.Location = New-Object System.Drawing.Point(725, 1)
$lblExit.Name = "lExit"
$lblExit.Size = New-Object System.Drawing.Size(26, 30)
$lblExit.Text = "X"
$frmMain.Controls.Add($lblExit)


$lblExit.add_MouseHover( { $lblExit.ForeColor = "Black" } )
$lblExit.add_MouseLeave( { $lblExit.ForeColor = "White" } )
$lblExit.add_MouseClick( { $frmMain.Close() } )


$lblMinimize = New-Object System.Windows.Forms.Label
$lblMinimize.Font = New-Object System.Drawing.Font("Segoe UI", 22, [System.Drawing.FontStyle]::Bold)
$lblMinimize.ForeColor = "White"
$lblMinimize.BackColor = "Steelblue"
$lblMinimize.Location = New-Object System.Drawing.Point(705, -12)
$lblMinimize.Size = New-Object System.Drawing.Size(28, 37)
$lblMinimize.Text = "_"
$frmMain.Controls.Add($lblMinimize)


$lblMinimize.add_MouseHover( { $lblMinimize.ForeColor = "Black" } )
$lblMinimize.add_MouseLeave( { $lblMinimize.ForeColor = "White" } )
$lblMinimize.add_MouseClick( { $frmMain.WindowState = "minimized" } )


$pnlHeader = New-Object System.Windows.Forms.Panel
$pnlHeader.Location = New-Object System.Drawing.Point(1, 1)
$pnlHeader.BackColor = "SteelBlue"
$pnlHeader.Size = New-Object System.Drawing.Size(748, 32)
$frmMain.Controls.Add($pnlHeader)
MakeControlmovable($pnlHeader)


# ------------------------------------------------------------------------------
#   Panel with radiobuttons, choices
# ------------------------------------------------------------------------------
$rbtChoice1 = New-Object System.Windows.Forms.Radiobutton
$rbtChoice1.Font = $fntMain
$rbtChoice1.ForeColor = "Gray"
$rbtChoice1.Location = New-Object System.Drawing.Point(491, 56)
$rbtChoice1.Size = New-Object System.Drawing.Size(225, 17)
$rbtChoice1.Text = "System - PreInstall"
$rbtChoice1.Tabstop = $False
$frmMain.Controls.Add($rbtChoice1)
    $rbtChoice1.Add_Click( { 
        $frmMain.Controls | where-object { $_.GetType().Name -eq "RadioButton" } | foreach-object { $_.ForeColor = "Gray" }
        $this.forecolor = "Steelblue"
        $lblForm1.text = "System Name"
        $lblForm2.Text = "System Number"
        $tbxNumber.Text = "SY" + ($tbxNumber.Text).substring(2)
        $lblForm3.Visible = $False
        $tbxFix.Visible = $False
        $lblForm4.Text = "System Build"
    })


$rbtChoice2 = New-Object System.Windows.Forms.Radiobutton
$rbtChoice2.Font = $fntMain
$rbtChoice2.ForeColor = "Gray"
$rbtChoice2.Location = New-Object System.Drawing.Point(491, 76)
$rbtChoice2.Size = New-Object System.Drawing.Size(225, 17)
$rbtChoice2.Text = "System - PostInstall"
$rbtChoice2.Tabstop = $False
$frmMain.Controls.Add($rbtChoice2)
    $rbtChoice2.Add_Click( { 
        $frmMain.Controls | where-object { $_.GetType().Name -eq "RadioButton" } | foreach-object { $_.ForeColor = "Gray" }
        $this.forecolor = "Steelblue"
       $this.forecolor = "Steelblue"
        $lblForm1.text = "System Name"
        $lblForm2.Text = "System Number"
        $tbxNumber.Text = "SY" + ($tbxNumber.Text).substring(2)
        $lblForm3.Visible = $False
        $tbxFix.Visible = $False
        $lblForm4.Text = "System Build"
    })


$rbtChoice3 = New-Object System.Windows.Forms.Radiobutton
$rbtChoice3.Font = $fntMain
$rbtChoice3.ForeColor = "Gray"
$rbtChoice3.Location = New-Object System.Drawing.Point(491, 96)
$rbtChoice3.Size = New-Object System.Drawing.Size(225, 17)
$rbtChoice3.Text = "Fix"
$rbtChoice3.Tabstop = $False
$frmMain.Controls.Add($rbtChoice3)
    $rbtChoice3.Add_Click( { 
        $frmMain.Controls | where-object { $_.GetType().Name -eq "RadioButton" } | foreach-object { $_.ForeColor = "Gray" }
        $this.forecolor = "Steelblue"
        $lblForm1.text = "System Name"
        $lblForm2.Text = "System Number"
        $tbxNumber.Text = "SY" + ($tbxNumber.Text).substring(2)
        $lblForm3.Visible = $True
        $tbxFix.Visible = $True
        $lblForm4.Text = "System Build"
    })


$rbtChoice4 = New-Object System.Windows.Forms.Radiobutton
$rbtChoice4.Font = $fntMain
$rbtChoice4.ForeColor = "Gray"
$rbtChoice4.Location = New-Object System.Drawing.Point(491, 116)
$rbtChoice4.Size = New-Object System.Drawing.Size(225, 17)
$rbtChoice4.Text = "Component"
$rbtChoice4.Tabstop = $False
$frmMain.Controls.Add($rbtChoice4)
    $rbtChoice4.Add_Click( { 
        $frmMain.Controls | where-object { $_.GetType().Name -eq "RadioButton" } | foreach-object { $_.ForeColor = "Gray" }
        $this.forecolor = "Steelblue"
        $lblForm1.text = "Component Name"
        $lblForm2.Text = "Component Number"
        $tbxNumber.Text = "CO" + ($tbxNumber.Text).substring(2)
        $lblForm3.Visible = $False
        $tbxFix.Visible = $False
        $lblForm4.Text = "Component Build"
   })



$rbtChoice5 = New-Object System.Windows.Forms.Radiobutton
$rbtChoice5.Font = $fntMain
$rbtChoice5.ForeColor = "Gray"
$rbtChoice5.Location = New-Object System.Drawing.Point(491, 136)
$rbtChoice5.Size = New-Object System.Drawing.Size(225, 17)
$rbtChoice5.Text = "uCD Controlled Manual Install"
$rbtChoice5.Tabstop = $False
$frmMain.Controls.Add($rbtChoice5)
    $rbtChoice5.Add_Click( { 
        $frmMain.Controls | where-object { $_.GetType().Name -eq "RadioButton" } | foreach-object { $_.ForeColor = "Gray" }
        $this.forecolor = "Steelblue"
        $lblForm1.text = "System Name"
        $lblForm2.Text = "System Number"
        $tbxNumber.Text = "SY" + ($tbxNumber.Text).substring(2)
        $lblForm3.Visible = $False
        $tbxFix.Visible = $False
        $lblForm4.Text = "System Build"
   })


# Could have used a groupbox here, but I want a thick border
$pnlChoices1 = New-Object System.Windows.Forms.Panel
$pnlChoices1.Location = New-Object System.Drawing.Point(471, 48)
$pnlChoices1.Size = New-Object System.Drawing.Size(258, 114)
$frmMain.Controls.Add($pnlChoices1)
MakeControlmovable $pnlChoices1 


$pnlChoices2 = New-Object System.Windows.Forms.Panel
$pnlChoices2.Location = New-Object System.Drawing.Point(470, 47)
$pnlChoices2.BackColor = "DarkGray"
$pnlChoices2.Size = New-Object System.Drawing.Size(260, 116)
$frmMain.Controls.Add($pnlChoices2)
MakeControlmovable $pnlChoices2 



# ------------------------------------------------------------------------------
#   Static text labels
# ------------------------------------------------------------------------------
$lblForm1 = New-Object System.Windows.Forms.Label
$lblForm1.Font = $fntMain
$lblForm1.ForeColor = "Gray"
$lblForm1.Location = New-Object System.Drawing.Point(20, 84)
$lblForm1.Size = New-Object System.Drawing.Size(140, 17)
$lblForm1.Text = "System Name"
$frmMain.Controls.Add($lblForm1)
MakeControlmovable $lblForm1 


$lblForm2 = New-Object System.Windows.Forms.Label
$lblForm2.Font = $fntMain
$lblForm2.ForeColor = "Gray"
$lblForm2.Location = New-Object System.Drawing.Point(20, 107)
$lblForm2.Size = New-Object System.Drawing.Size(140, 17)
$lblForm2.Text = "System Number"
$frmMain.Controls.Add($lblForm2)
MakeControlmovable $lblForm2 


$lblForm3 = New-Object System.Windows.Forms.Label
$lblForm3.Font = $fntMain
$lblForm3.ForeColor = "Gray"
$lblForm3.Location = New-Object System.Drawing.Point(270, 107)
$lblForm3.Size = New-Object System.Drawing.Size(90, 17)
$lblForm3.Text = "Fix Number"
$frmMain.Controls.Add($lblForm3)
MakeControlmovable $lblForm3 


$lblForm4 = New-Object System.Windows.Forms.Label
$lblForm4.Font = $fntMain
$lblForm4.ForeColor = "Gray"
$lblForm4.Location = New-Object System.Drawing.Point(20, 130)
$lblForm4.Size = New-Object System.Drawing.Size(140, 17)
$lblForm4.Text = "System Build"
$frmMain.Controls.Add($lblForm4) 
MakeControlmovable $lblForm4 


$lblForm5 = New-Object System.Windows.Forms.Label
$lblForm5.Font = $fntMain
$lblForm5.ForeColor = "Gray"
$lblForm5.Location = New-Object System.Drawing.Point(20, 153)
$lblForm5.Size = New-Object System.Drawing.Size(100, 17)
$lblForm5.Text = "uCD Version"
$frmMain.Controls.Add($lblForm5) 
MakeControlmovable $lblForm5 


$lblForm6 = New-Object System.Windows.Forms.Label
$lblForm6.Font = $fntMain
$lblForm6.ForeColor = "Gray"
$lblForm6.Location = New-Object System.Drawing.Point(20, 176)
$lblForm6.Size = New-Object System.Drawing.Size(100, 17)
$lblForm6.Text = "Repository"
$frmMain.Controls.Add($lblForm6) 
MakeControlmovable $lblForm6 


$lblForm7 = New-Object System.Windows.Forms.Label
$lblForm7.Font = $fntMain
$lblForm7.ForeColor = "Gray"
$lblForm7.Location = New-Object System.Drawing.Point(20, 209)
$lblForm7.Size = New-Object System.Drawing.Size(100, 17)
$lblForm7.Text = "Output Folder"
$frmMain.Controls.Add($lblForm7) 
MakeControlmovable $lblForm7 



# ------------------------------------------------------------------------------
#   Non-static 
# ------------------------------------------------------------------------------
$tbxName = New-Object System.Windows.Forms.Textbox
$tbxName.Font = $fntMain
$tbxName.ForeColor = "DimGray"
$tbxName.Location = New-Object System.Drawing.Size(160, 84)
$tbxName.Size = New-Object System.Drawing.Size(290, 17)
$tbxName.Text = ""
$tbxName.Borderstyle = "None"
$tbxName.Tabstop = $False
$frmMain.Controls.Add($tbxname)
$tbxName.add_Enter({ $this.Forecolor = "Steelblue" })
$tbxName.add_Leave({ $this.Forecolor = "DimGray" })
$tbxName.add_MouseHover( { $this.BackColor = "Lavender" } )
$tbxName.add_MouseLeave( { $this.BackColor = "White" } )
$tbxName.Add_KeyUp({if ($_.KeyCode -eq "Enter") {$rtbLog.Focus()} })


$tbxNumber = New-Object System.Windows.Forms.Textbox
$tbxNumber.Font = $fntMain
$tbxNumber.ForeColor = "DimGray"
$tbxNumber.Location = New-Object System.Drawing.Size(160, 107)
$tbxNumber.Size = New-Object System.Drawing.Size(90, 17)
$tbxNumber.Borderstyle = "None"
$tbxNumber.Tabstop = $False
$frmMain.Controls.Add($tbxNumber)
$tbxNumber.add_Enter({ $this.Forecolor = "Steelblue" })
$tbxNumber.add_Leave({ $this.Forecolor = "DimGray" })
$tbxNumber.add_MouseHover( { $this.BackColor = "Lavender" } )
$tbxNumber.add_MouseLeave( { $this.BackColor = "White" } )
$tbxNumber.Add_KeyUp({if ($_.KeyCode -eq "Enter") {$rtbLog.Focus()} })


$tbxFix = New-Object System.Windows.Forms.Textbox
$tbxFix.Font = $fntMain
$tbxFix.ForeColor = "DimGray"
$tbxFix.Location = New-Object System.Drawing.Size(360, 107)
$tbxFix.Size = New-Object System.Drawing.Size(90, 17)
$tbxFix.Borderstyle = "None"
$tbxFix.Tabstop = $False
$frmMain.Controls.Add($tbxFix)
$tbxFix.add_Enter({ $this.Forecolor = "Steelblue" })
$tbxFix.add_Leave({ $this.Forecolor = "DimGray" })
$tbxFix.add_MouseHover( { $this.BackColor = "Lavender" } )
$tbxFix.add_MouseLeave( { $this.BackColor = "White" } )
$tbxFix.Add_KeyUp({if ($_.KeyCode -eq "Enter") {$rtbLog.Focus()} })


$tbxBuild = New-Object System.Windows.Forms.Textbox
$tbxBuild.Font = $fntMain
$tbxBuild.ForeColor = "DimGray"
$tbxBuild.Location = New-Object System.Drawing.Size(160, 130)
$tbxBuild.Size = New-Object System.Drawing.Size(90, 17)
$tbxBuild.Borderstyle = "None"
$tbxBuild.Tabstop = $False
$frmMain.Controls.Add($tbxBuild)
$tbxBuild.add_Enter({ $this.Forecolor = "Steelblue" })
$tbxBuild.add_Leave({ $this.Forecolor = "DimGray" })
$tbxBuild.add_MouseHover( { $this.BackColor = "Lavender" } )
$tbxBuild.add_MouseLeave( { $this.BackColor = "White" } )
$tbxBuild.Add_KeyUp({if ($_.KeyCode -eq "Enter") {$rtbLog.Focus()} })


$tbxVersion = New-Object System.Windows.Forms.Textbox
$tbxVersion.Font = $fntMain
$tbxVersion.ForeColor = "DimGray"
$tbxVersion.Location = New-Object System.Drawing.Size(160, 153)
$tbxVersion.Size = New-Object System.Drawing.Size(90, 17)
$tbxVersion.Borderstyle = "None"
$tbxVersion.Tabstop = $False
$frmMain.Controls.Add($tbxVersion)
$tbxVersion.add_Enter({ $this.Forecolor = "Steelblue" })
$tbxVersion.add_Leave({ $this.Forecolor = "DimGray" })
$tbxVersion.add_MouseHover( { $this.BackColor = "Lavender" } )
$tbxVersion.add_MouseLeave( { $this.BackColor = "White" } )
$tbxVersion.Add_KeyUp({if ($_.KeyCode -eq "Enter") {$rtbLog.Focus()} })


$tbxRepository = New-Object System.Windows.Forms.Textbox
$tbxRepository.Font = $fntMain
$tbxRepository.ForeColor = "DimGray"
$tbxRepository.Location = New-Object System.Drawing.Size(160, 176)
$tbxRepository.Size = New-Object System.Drawing.Size(570, 17)
$tbxRepository.Text = $Repository
$tbxRepository.Borderstyle = "None"
$tbxRepository.Tabstop = $False
$frmMain.Controls.Add($tbxRepository)
$tbxRepository.add_Enter({ $this.Forecolor = "Steelblue" })
$tbxRepository.add_Leave({ $this.Forecolor = "DimGray" })
$tbxRepository.add_MouseHover( { $this.BackColor = "Lavender" } )
$tbxRepository.add_MouseLeave( { $this.BackColor = "White" } )
$tbxRepository.Add_KeyUp({if ($_.KeyCode -eq "Enter") {$rtbLog.Focus()} })


$tbxOutputFolder = New-Object System.Windows.Forms.TextBox 
$tbxOutputFolder.Font = $fntMain
$tbxOutputFolder.ForeColor = "DimGray"
$tbxOutputFolder.Borderstyle = "None"
$tbxOutputFolder.Location = New-Object System.Drawing.Size(160, 209) 
$tbxOutputFolder.Size = New-Object System.Drawing.Size(420,23) 
$tbxOutputFolder.Text = $OutputFolder
$tbxOutputFolder.TabStop = $False
$frmMain.Controls.Add($tbxOutputFolder) 
$tbxOutputFolder.Add_Click({ $tbxOutputFolder.ForeColor = "Steelblue"; BrowseFolder; $tbxOutputFolder.ForeColor = "DimGray" })
$tbxOutputFolder.add_Enter({ $this.Forecolor = "Steelblue" })
$tbxOutputFolder.add_Leave({ $this.Forecolor = "DimGray" })
$tbxOutputFolder.add_MouseHover( { $this.BackColor = "Lavender" } )
$tbxOutputFolder.add_MouseLeave( { $this.BackColor = "White" } )


$rtbLog = New-Object System.Windows.Forms.RichTextBox
$rtbLog.Font = $fntMain
$rtbLog.ForeColor = "Dimgray"
$rtbLog.backcolor = "Lavender"
$rtbLog.Location = New-Object System.Drawing.Point(20, 251)
$rtbLog.Size = New-Object System.Drawing.Size(710, 196)
$rtbLog.multiline = $True
$rtbLog.Text = ""
$rtbLog.HideSelection = $False
$frmMain.Controls.Add($rtbLog) 
MakeControlmovable $rtbLog 



# ------------------------------------------------------------------------------
#   Generate Button
# ------------------------------------------------------------------------------
$btnGenerate = New-Object System.Windows.Forms.Button
$btnGenerate.Font = $fntMain
$btnGenerate.Flatstyle = [System.Windows.Forms.FlatStyle]::System
$btnGenerate.Location = New-Object System.Drawing.Point(650, 207)
$btnGenerate.Size = New-Object System.Drawing.Size(80, 23)
$btnGenerate.Text = "Generate"
$frmMain.Controls.Add($btnGenerate)
$btnGenerate.Add_Click({ $Check = (CheckFormInput); If ($Check -eq "OK") { GenerateOutput} })



# ------------------------------------------------------------------------------
#   Form startup tasks
# ------------------------------------------------------------------------------
$frmMain.add_Load( { 

    $tbxNumber.Text  = ("SY" + (Get-Date -Format "yyMMdd") + "01")
    $tbxFix.Text     = ("Fix" + (Get-Date -Format "yyyyMMdd"))
    $tbxBuild.Text   = "1.0"
    $tbxVersion.Text = "1_01"

    Appendlog -AppendText "---  Automated Deployment Template Generator Version $ADTVersion ---" -MessageType "Information"

    $global:WordIntegration = $False
    Try {
        $Word = new-object -comobject Word.Application
        $Word.quit()
        $Word = $null
        $global:WordIntegration = $True
    }
    Catch {
        Appendlog -AppendText "---  Word COM object can't be created. Disabling word integration. Please (re)install MS office.  ---" -MessageType "Information"
    }

    $rbtChoice2.PerformClick()    # Second radiobutton as default, 'System - Post Install' 

    $rtbLog.Focus()               # Always keep the focus on the log box
    
} ) 




