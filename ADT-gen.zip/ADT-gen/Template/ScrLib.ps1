#-------------------------------------------------------------------------------
#  SCRLIB.PS1 contains all standard functions used by INSTALL.PS1.
#  
#  Write-Log		   Writes a message to screen and log file  
#  Get-OSVersion	   Retrieves the OS version information
#  Check-ExitCode	   Retrieves the last error code
#  Register-Component	   Writes system or component information to registry
#  Get-SolonEnvironment	   Reads the ENVIRONMENT environment variable
#  Get-JoinedDomain	   Reads the JoinedDomain environment variable
#  Get-CurrentUser	   Returns the name of the user that started the script
#  SeverManagerCmd-Execute Add windowsfeatures
#  Get-Inicontent	   Gets the content of an INI file
#  Check-CMSroles	   Check if the system has CMS roles installed 
#  Expand-ZIPfile	   Unzip a zipfile to a specific destination
#-------------------------------------------------------------------------------

#-------------------------------------------------------------------------------
#  Function   Write-Log
#  Purpose    Writes a message to the screen and to a log file
#  Returns    nothing
# 
#  Examples   Write-Log -Message "Log entry created."
#             Write-Log -Message "Success message" -Type "Success"
#-------------------------------------------------------------------------------
Function Write-Log {
    Param (
        [Parameter(Mandatory = $True, Position = 0)] [String] $Message,
        [Parameter(Mandatory = $False, Position = 1)] [String] $Type
    )
    
    switch ($Type) {
        "NoTimeStamp" { $Textcolor = "Gray"  }
        "Error"       { $Textcolor = "Red"   }
        "Information" { $Textcolor = "White" }
        "Success"     { $Textcolor = "Green" }
        default       { $Textcolor = "Gray"  }
    }
     
    # Create log directory when needed
    If ((Test-Path -Path $LogDir) -eq $False) {
        New-Item $LogDir -Type Directory | Out-Null
    }

    $TimeStamp = "[" + (Get-Date -Format dd-MM-yy) + "," + (Get-Date -Format HH:mm:ss) + "] "
    $Log = $TimeStamp + $Message
 
    # Write to screen
    If (!($Type -eq "NoTimeStamp")) {
        Write-Host -Foregroundcolor "DarkGray" -Object $TimeStamp -NoNewLine
    }
    Write-Host -Foregroundcolor $TextColor -Object $Message 
   
    # Write to log file
    Add-Content -Path $LogFile -Value $Log
}


#-------------------------------------------------------------------------------
#  Function   Get-OSVersion
#  Purpose    Retrieves the OS version information and writes it to the log
#  Returns    the (short) OS name
# 
#  Example    $OSVersion = Get-OSVersion -Name $Computer
#             Writes long info to screen and saves short OS name to $OSVersion
#-------------------------------------------------------------------------------
Function Get-OSVersion {
    Param (
        [Parameter(Mandatory = $True)] [String] $Name
    )

    $Win32_OS = Get-WmiObject -Class Win32_OperatingSystem -ComputerName $Name
    $OSVersion = "Win2008R2"

    Switch ($Win32_OS.BuildNumber) {
        "2600" { $OSVersion = "WinXP";   Break }
        "3790" { $OSVersion = "Win2003"; Break }
        "[6000-6001]" { If ($Win32_OS.caption -match "Vista")     { $OSVersion = "WinVista" } Else { $OSVersion = "Win2008" };   Break }
        "[7100-7601]" { If ($Win32_OS.Caption -match "Windows 7") { $OSVersion = "Win7" }     Else { $OSVersion = "Win2008R2" }; Break }
        "[9200-9999]" { If ($Win32_OS.Caption -match "Windows 8") { $OSVersion = "Win8" }     Else { $OSVersion = "Win2012" };   Break }
    }

    $OSFullDescription = " $($Win32_OS.Caption.TrimEnd())"

    If (!($Win32_OS.ServicePackMajorVersion -eq 0)) {
    $OSFullDescription += " SP$($Win32_OS.ServicePackMajorVersion)"
    }

    Write-Log $OSFullDescription

    Return $OSVersion
}


#-------------------------------------------------------------------------------
#  Function   Check-ExitCode
#  Purpose    Retrieves the error code from the last executed program and
#             converts the error into a successful or failed exit code, then
#             writes the result to log or exits with error code.
#  Returns    nothing
# 
#  Example    Check-ExitCode -Code $LastExitCode
#-------------------------------------------------------------------------------
Function Check-ExitCode {
    Param (
        [Parameter(Mandatory = $True, ValueFromPipeline = $True)] [Int] $Code
    )

    Process {
        Switch ($Code) {
            1203  { $Code = 0 }                                       # ERROR_NO_NET_OR_BAD_PATH
            1605  { $Code = 0 }                                       # ERROR_UNKNOWN_PRODUCT
            1641  { $Code = 0; $ExtraMessage = " Reboot initiated." } # ERROR_SUCCESS_REBOOT_INITIATED
            3010  { $Code = 0; $ExtraMessage = " Reboot required."  } # ERROR_SUCCESS_REBOOT_REQUIRED
        }
       
        If ($Code -ne 0) {
            Write-Log -Message "Execution failed!" -Type "Error"
            Throw "Exited with error code: $Code"
        }
        
        Write-Log -Message "Execution successful. $ExtraMessage" -Type "Success"
    }
}


#-------------------------------------------------------------------------------
#  Function   Register-Component
#  Purpose    Writes the system or component information to the registry
#  Returns    nothing
# 
#  Example    Register-Component $Number $Name $Build
#-------------------------------------------------------------------------------
Function Register-Component {
    Param (
        [Parameter(Mandatory = $True)] [String] $RFC,
        [Parameter(Mandatory = $True)] [String] $Name,
        [Parameter(Mandatory = $True)] [String] $Build
    )

    If ($RFC.StartsWith("SY")) { 
        $CascadeLocation += "\Systems"
        if (($name.toupper()).EndsWith("-PREINSTALL")) {
            $RegKey = $RegistryKeySAS + "\" + $RFC + " - PreInstall"
            $Location  = $CascadeLocation + "\" + $RFC + " - " + ($Name.substring(0,($Name.Length-11))) + "\PreInstall"
       }
        else {
            $RegKey = $RegistryKeySAS + "\" + $RFC + " - PostInstall"
            $Location  = $CascadeLocation + "\" + $RFC + " - " + ($Name.substring(0,($Name.Length-12))) + "\PostInstall"
       }
    }
    Else {
        $CascadeLocation += "\Components"
        $RegKey = $RegistryKeySAS + "\" + $RFC
        $Location  = $CascadeLocation + "\" + $RFC + " - " + $Name
    }
    
    $Installed = (Get-Date -Format dd-MM-yyyy) + " " + (Get-Date -Format HH:mm:ss)
    
    # Create registry key only when it does not exist
    If (-not (Test-Path -Path $RegistryKeySAS)) {
        New-Item -Path $RegistryKeySAS | Out-Null
    }
    
    If (-not (Test-Path -Path $RegKey)) {
        New-Item -Path $RegKey | Out-Null
    }
    
    # Create or modify registry values (properties of above key)
    Set-ItemProperty -Path $RegKey -Name Build           -Value $Build        | Out-Null
    Set-ItemProperty -Path $RegKey -Name InstallDate     -Value $Installed    | Out-Null
    Set-ItemProperty -Path $RegKey -Name CascadeLocation -Value $Location     | Out-Null
    Set-ItemProperty -Path $RegKey -Name Name            -Value $Name         | Out-Null
    Set-ItemProperty -Path $RegKey -Name TemplateDate    -Value $TemplateDate | Out-Null
    
    Write-Log -Message "Component information written to registry" -Type "Information"
}


#-------------------------------------------------------------------------------
#  Function   Get-SolonEnvironment
#  Purpose    Reads the ENVIRONMENT environment variable
#  Returns    the (short) Solon environment (T
# 
#  Example    $Environment = Get-SolonEnvironment
#             Writes long info to screen and saves short info to $Environment
#-------------------------------------------------------------------------------
Function Get-SolonEnvironment {
    $SolonEnvironment = $Env:ENVIRONMENT

    Switch ($SolonEnvironment) {
        "T"  { $Environment = "TEST" } 
        "Q"  { $Environment = "QUALITY ASSURANCE" } 
        "P"  { $Environment = "PRODUCTION" }
    }

    Write-Log -Message " Solon $Environment environment"
  
    Return $SolonEnvironment
}


#-------------------------------------------------------------------------------
#  Function   Get-JoinedDomain
#  Purpose    Reads the JoinedDomain environment variable 
#  Returns    the JoinedDomain environment variable
# 
#  Example    $Domain = Get-JoinedDomain
#             Writes domain name to screen and saves it to $Domain
#-------------------------------------------------------------------------------
Function Get-JoinedDomain {
    # Use JoinedDOMAIN to make it available under SYSTEM context as well
    Write-Log -Message " $Env:JoinedDOMAIN domain"
  
    Return $Env:JoinedDOMAIN
}


#-------------------------------------------------------------------------------
#  Function   Get-CurrentUser
#  Purpose    Returns the name of the user that started the script 
#  Returns    The name of the user that started the script
# 
#  Example    Get-CurrentUser
#-------------------------------------------------------------------------------
Function Get-CurrentUser {
    $User = [Security.Principal.WindowsIdentity]::GetCurrent().Name
    Write-Log -Message " Script executed by $User"
  
    Return $User
}


#-------------------------------------------------------------------------------
#  Function   SeverManagerCmd-Execute
#  Purpose    Adds windowsfeatures
# 
#  Example    $ArrFeathers=@()
#             $ArrFeathers+="NET-Framework-Features"
#             $ArrFeathers+="NET-Framework-Core"
#             $FeatureSelection=[system.String]::Join(" ", $ArrFeathers)
#
#             ServerManagerCmd-Execute $FeatureSelection 
#-------------------------------------------------------------------------------
Function SeverManagerCmd-Execute {
    Param ( [Parameter(Mandatory = $True)] [String] $FeatureSelection)

    $FeatureCollection =Get-WindowsFeature | where { "$($FeatureSelection)".IndexOf($_.name) -gt -1} 

	foreach ($item in  $FeatureCollection) {  
        if (!($item.Installed)) {
            try {
                Add-WindowsFeature $item.name  -ErrorAction Stop
                Write-Log -Message "$($item.Name) installed"
			}
            catch {
                Write-Log -Message  "error installing $($item.Name)"
            }
        }
        else {
            Write-Log -Message "$($item.Name) installed"
		}
    }
 }


#-------------------------------------------------------------------------------
#  Function   Get-IniContent
#  Purpose    Gets the content of an INI file and returns it as a hashtable 
#  Returns    a hashtable
# 
#  Example    $FileContent = Get-IniContent "c:\settings.ini"  
#             $FileContent["Section"]["Key"]
#-------------------------------------------------------------------------------
Function Get-IniContent {     
    Param ([Parameter(Mandatory = $True)] [string] $iniFilePath)
	        
    $ini = @{}  
    if (-not (Test-Path $iniFilePath )) {
        return $ini
    }

    $section="no-section"
    $lines=Get-Content $iniFilePath
	
    foreach($line in $lines) {	
        if ( $line.StartsWith(";") -or $line.StartsWith("#") ) {
            # skip comment 
            Continue  #---------->jump
        }
        if ($line.StartsWith("[") -and $line.EndsWith("]") ) {
            #get section
            $section=$line.SubString(1,$line.Length-2)
            $ini[$section] = @{}  
            Continue  #---------->jump
        }

        $npos=$line.IndexOf("=")
        if ($npos -gt 1) { # key+= mimimum length 2  
            $keyRaw	= $line.Substring(0,$npos+1)   # include =
            $key	= $keyRaw.replace("=","").Trim()
            $value	= ""
            if ($line.Length -gt $npos+1) {
                $value	=$line.Substring($npos+1)
            }
            if ($ini[$section] -eq $null) {  
                $ini[$section] = @{} 
            }
            $ini[$section][$key] = $value  
        }
    }
    return $ini
}		




#-------------------------------------------------------------------------------
#  Function   Check-CMSroles
#  Purpose    Check if the system has one or more CMS roles installed 
#  Returns    $true if installed, $false if not. if the parameter is omitted,
#             nothing is returned.
# 
#  Example1   Check-CMSroles
#             Without parameters, all installed CMS roles are enumerated, in 
#             the standard message format.
#  Example2   Check-CMSroles("SQL client")
#             Checks if the server has the SQL client role installed           
#-------------------------------------------------------------------------------
Function Check-CMSRoles {
    Param ( [Parameter(Mandatory = $False)] [String] $Role)

    If (!($Role)) { 
        $InstalledRoles = ""
        If (Test-Path 'D:\Data\IIS\wwwroot') { $InstalledRoles += "IIS server, " }
        If (Test-Path 'HKLM:\Software\IBM\Applications\CO16100101') { $InstalledRoles += "DB2 client, " }
        If (Test-Path 'HKLM:\Software\IBM\Applications\CO16100102') { $InstalledRoles += "SQL client, " }
        If (Test-Path 'HKLM:\Software\IBM\Applications\CO16100103') { $InstalledRoles += "Oracle client, " }
        If (Test-Path 'HKLM:\Software\IBM\Applications\CO16100104') { $InstalledRoles += "JRE, " }
        If (Test-Path 'HKLM:\Software\IBM\Applications\CO16100105') { $InstalledRoles += "Control-M client, " }
        If (Test-Path 'HKLM:\Software\IBM\Applications\CO16100106') { $InstalledRoles += "Z-centric client, " }

        If (!($InstalledRoles.Length -eq 0)) { 
            $InstalledRoles = $InstalledRoles.Substring(0, $InstalledRoles.Length-2) }

        If ($InstalledRoles.Length -gt 28) {
            For ($i = 28; $true; $i--) { 
                If ($InstalledRoles.Substring($i-1, 1) -eq ",") {
                    Write-Log -Message (" CMS roles installed: " + $InstalledRoles.substring(0,$i))
                    write-log -Message ("  " + $InstalledRoles.substring($i,$InstalledRoles.length-$i ))
                    break
                }
            }
        }
        Else {
            If (!($InstalledRoles.Length -eq 0)) { 
                Write-Log -Message " CMS roles installed: $InstalledRoles"
            }
            else {
                Write-Log -Message " CMS roles installed: none"
            }
        }


    }
    else {
        $RoleInstalled = $False
        Switch ($Role) {
            "IIS Server"       { If (Test-Path 'D:\Data\IIS\wwwroot') { $RoleInstalled = $True } }
            "DB2 Client"       { If (Test-Path 'HKLM:\Software\IBM\Applications\CO16100101') { $RoleInstalled = $True } }
            "SQL Client"       { If (Test-Path 'HKLM:\Software\IBM\Applications\CO16100102') { $RoleInstalled = $True } }
            "Oracle Client"    { If (Test-Path 'HKLM:\Software\IBM\Applications\CO16100103') { $RoleInstalled = $True } }
            "JRE"              { If (Test-Path 'HKLM:\Software\IBM\Applications\CO16100104') { $RoleInstalled = $True } }
            "Control-M Client" { If (Test-Path 'HKLM:\Software\IBM\Applications\CO16100105') { $RoleInstalled = $True } }
            "Z-Centric client" { If (Test-Path 'HKLM:\Software\IBM\Applications\CO16100106') { $RoleInstalled = $True } }

            default            {}  # Unknown role!
        }
        Return $RoleInstalled
    }
}




#-------------------------------------------------------------------------------
#  Function   Expand-ZIPFile
#  Purpose    Unzip a zipfile to a specific destination
#  Returns    $true on OK, $false on error.
# 
#  Example1   Expand-ZIPFile �File �C:\A.zip� �Destination �C:\temp\�
#             Unzips A.zip to folder c:\temp.
#-------------------------------------------------------------------------------
function Expand-ZIPFile($file, $destination) {
    $shell = new-object -com shell.application
    $ZIPfile = $shell.NameSpace($file)
    foreach($item in $zip.items()) {
        $shell.Namespace($destination).copyhere($item)
    }
}




#-------------------------------------------------------------------------------
#  Function   Set-security
#  Purpose    Set security on a folder
#  Returns    $true on OK, $false on error.
# 
#  Example    Set-security "d:\install" "Modify" "N46507A"
#             Grants modify permissions to user N46507A on folder d:\install
#             (You can grant "Read", "Modify", "Execute" or "Full")
#-------------------------------------------------------------------------------
Function Set-Security {
    Param ([string]$Folder, [String]$Permission, [string]$Username)


    $ACL = Get-ACL $Folder
    $ACL.SetAccessRuleProtection($False, $False)
    $ACL.AddAccessRule((New-Object System.Security.AccessControl.FileSystemAccessRule($Username,$Permission, "ContainerInherit, ObjectInherit", "None", "Allow")))
    Set-ACL $Folder $ACL
}

