#---------------------------------------------------------------------
#  INSTALL.PS1 installs a system or component
#---------------------------------------------------------------------

# - Constants --------------------------------------------------------
$CascadeLocation   = "WMW02\Scripting2012"
$LogDir            = "C:\LogFiles"
$RegistryKeySAS    = "HKLM:\SOFTWARE\IBM\Applications"
$TemplateDate      = "08-11-2016"

# - Script variables -------------------------------------
$AppLogFile      = ""
$Process         = ""
$ScriptDir       = Split-Path $MyInvocation.MyCommand.Path
$ScriptName      = $MyInvocation.MyCommand

# - Component/System variables -------------------------------------
$Build    = "----BUILD----"
$Name     = "----NAME----"
$Number   = "----NUMBER----"
$LogFile  = "$LogDir\$Number.log"

# - Include the function library and the MAIN script -----------------
Try {
    . "$ScriptDir\ScrLib.ps1"
    . "$Scriptdir\Main.ps1"
}
Catch {
    Write-Host -Foregroundcolor "Red" -Object "ERROR: Scrlib.ps1 or Main.ps1 not found, please investigate!"
    Exit 1
}



Try {
    # Write log header
    write-Host ""
    Write-Log -Message "$ScriptName started..." -Type "Information"
    Write-Log -Message "--------------------------------------------------"

    # Checking system and application version information for use in this script
    $OSVersion       = Get-OSVersion -Name "."
    $Environment     = Get-SolonEnvironment 
    $Domain          = Get-JoinedDomain 
                       Check-CMSroles
    $ScriptUser      = Get-CurrentUser

    Write-Log -Message "--------------------------------------------------"


    
    # Run the MAIN function which contains all custom actions
    Main


 
    # Register component/system to registry 
    Register-Component $Number $Name $Build


    Write-Log -Message "$ScriptName finished successfully" -Type "Success"
 

    Exit 0
}

Catch {
    Write-Log -Message "An error occured during execution, please investigate!" -Type "Error"
    Write-Log -Message "Refer to '$LogFile' for details." -Type "Error"

    Write-Log -Message $('-'*80) -Type "NoTimeStamp"
    Write-Log -Message "Error in         $($_.InvocationInfo.ScriptName)" -Type "NoTimeStamp"
    Write-Log -Message "Line Number      $($_.InvocationInfo.ScriptLineNumber)" -Type "NoTimeStamp"
    Write-Log -Message "Error details    $($_)" -Type "NoTimeStamp"
    Write-Log -Message "Command          $($_.InvocationInfo.MyCommand)" -Type "NoTimeStamp"
    Write-Log -Message "Line             $($_.InvocationInfo.Line)" -Type "NoTimeStamp"
    #Write-Log -Message "StackTrace       $($_.ScriptStackTrace)" -Type "NoTimeStamp"
    Write-Log -Message $('-'*80) -Type "NoTimeStamp"

    Add-Content -Path $LogFile -Value " " 
    $_ | format-list -force | Out-file $LogFile -Append -Encoding ascii
    
    Exit 1
}
