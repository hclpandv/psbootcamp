#---------------------------------------------------------------------
#  MAIN.PS1 is the place you put all custom actions for an
#           application. This is the only script you need to edit.
#           It is called by ----SCRIPT----
#---------------------------------------------------------------------
Function Main {   

----COMMENTS----
 

}